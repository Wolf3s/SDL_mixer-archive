This is an example portable sound library for use with SDL.

The source code is available from: http://www.libsdl.org/projects/SDL_mixer

This library is distributed under the terms of the GNU LGPL license: http://www.gnu.org/copyleft/lesser.html
