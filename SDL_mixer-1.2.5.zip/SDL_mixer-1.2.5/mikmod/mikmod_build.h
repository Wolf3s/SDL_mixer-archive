#include "mikmod.h"

#if defined(WIN32) && !defined(__STDC__)
#  define __STDC__ 1
#endif

#if defined(WIN32) && defined(_MSC_VER)
#  pragma warning(disable: 4018 4244)
#endif
